package Model;

import java.util.ArrayList;

public class Line {
	
	private ArrayList<String> words = new ArrayList<String>();
	
	public Line(String line) {
		String s[] = line.split("\\s+");
		for(String i : s) {
			words.add(i);
		}
	}
	
}
