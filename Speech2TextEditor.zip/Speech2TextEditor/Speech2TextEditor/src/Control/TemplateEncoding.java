package Control;

public abstract class TemplateEncoding implements EncodingStrategy{
	public abstract String encode(String str);
}
