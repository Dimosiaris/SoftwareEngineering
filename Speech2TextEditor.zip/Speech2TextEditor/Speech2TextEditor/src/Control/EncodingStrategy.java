package Control;
// Choosing the encoding strategy
public interface EncodingStrategy {
	public  String encode(String str);
}